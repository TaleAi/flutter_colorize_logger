# colorize_logger

a colorize logger for flutter, you can also customize。

## 中文说明

一个可以定制的flutter日志系统，debug模式下会打印日志，release模式关闭日志

## screenshots

![截图](./art/screenshot.png)

## how to use ?

```dart
if (Logger.isReleaseMode()) {
      /// use file
      Directory directory = await getApplicationDocumentsDirectory();
      final currentDate = DateTime.now();
      final fileName =
          '${currentDate.year}-${currentDate.month}-${currentDate.day}-logs.txt';
      Logger.client = FileLoggerClient(filePath: '${directory.path}/$fileName');

      /// use sentry
      // await SentryFlutter.init(
      //   (options) {
      //     options.dsn = 'https://example@sentry.io/add-your-dsn-here';
      //   },
      // );
      // Logger.client = SentryLoggerClient();
} else {
    /// debug
      Logger.client = ColorizeLoggerClient();
}
```