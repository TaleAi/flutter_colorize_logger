import 'dart:async';
import 'dart:io';

import 'package:colorize_logger/colorize_logger.dart';
import 'package:flutter/widgets.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sentry_flutter/sentry_flutter.dart';

class Startup {
  static void startAPP(Widget app) async {
    if (Logger.isReleaseMode()) {
      /// 使用文件存储的方式
      Directory directory = await getApplicationDocumentsDirectory();
      final currentDate = DateTime.now();
      final fileName =
          '${currentDate.year}-${currentDate.month}-${currentDate.day}-logs.txt';
      Logger.client = FileLoggerClient(filePath: '${directory.path}/$fileName');

      /// 使用sentry
      // await SentryFlutter.init(
      //   (options) {
      //     options.dsn = 'https://example@sentry.io/add-your-dsn-here';
      //   },
      // );
      // Logger.client = SentryLoggerClient();
    } else {
      Logger.client = ColorizeLoggerClient();
    }
    _runApp(app);
  }

  static _runApp(Widget app) {
    FlutterError.onError = (details) async {
      if (PlatformChecker().isReleaseMode()) {
        Zone.current.handleUncaughtError(
          details.exception,
          details.stack ?? StackTrace.empty,
        );
      } else {
        FlutterError.dumpErrorToConsole(details);
      }
    };
    runZonedGuarded(
      () => runApp(app),
      (e, s) async {
       Logger.error(e, stacktrace: s);
      },
    );
  }
}