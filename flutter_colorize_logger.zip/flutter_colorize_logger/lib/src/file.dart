import 'dart:io';

import 'package:colorize_logger/colorize_logger.dart';
import 'package:synchronized/synchronized.dart';

class FileLoggerClient extends LoggerClient {
  File _logFile;
  static final _lock = Lock();

  FileLoggerClient({
    required String filePath,
  }) : _logFile = File(filePath);

  @override
  void error(dynamic exception, {dynamic stacktrace, String? tag}) {
    _log(_format(tag ?? 'ERROR', 'exception: $exception \n stacktrace: $stacktrace'));
  }

  @override
  void fatal(String message, {String? tag}) {
    _log(_format(tag ?? 'FATAL', message));
  }

  @override
  void info(String message, {String? tag}) {
    _log(_format(tag ?? 'INFO', message));
  }

  @override
  void warning(String message, {String? tag}) {
    _log(_format(tag ?? 'WARNING', message));
  }

  String _format(String tag, String message) {
    return '[$tag] $message';
  }

  _log(String message) async {
    try {
      _lock.synchronized(() async {
        final date = DateTime.now();
        await _logFile.writeAsString(
          '${date.toIso8601String()}${date.timeZoneOffset} - $message\n',
          mode: FileMode.writeOnlyAppend,
          flush: true,
        );
      });
    } catch (e) {
      print("logger exception: $e");
    }
  }
}
