import 'package:colorize_logger/colorize_logger.dart';
import 'package:sentry/sentry.dart';

class SentryLoggerClient extends LoggerClient {
  Hub _hub;

  SentryLoggerClient({Hub? hub}) : _hub = hub ?? HubAdapter();

  @override
  void error(dynamic exception, {dynamic stacktrace, String? tag}) {
    _hub.captureException(exception, stackTrace: stacktrace);
  }

  @override
  void fatal(String message, {String? tag}) {
    _hub.addBreadcrumb(Breadcrumb(
      level: SentryLevel.fatal,
      message: message,
      data: {'tag': tag},
    ));
  }

  @override
  void info(String message, {String? tag}) {
    _hub.addBreadcrumb(Breadcrumb(
      level: SentryLevel.info,
      message: message,
      data: {'tag': tag},
    ));
  }

  @override
  void warning(String message, {String? tag}) {
    _hub.addBreadcrumb(Breadcrumb(
      level: SentryLevel.warning,
      message: message,
      data: {'tag': tag},
    ));
  }
}
