abstract class LoggerClient {
  void info(String message, {String? tag});
  void warning(String message, {String? tag});
  void error(dynamic exception, {dynamic stacktrace,String? tag});
  void fatal(String message, {String? tag});
}
