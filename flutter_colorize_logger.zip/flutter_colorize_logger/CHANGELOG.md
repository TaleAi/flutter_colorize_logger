## V1.0.0

* core api.

## V1.1.0

* add file log
* add sentry log
